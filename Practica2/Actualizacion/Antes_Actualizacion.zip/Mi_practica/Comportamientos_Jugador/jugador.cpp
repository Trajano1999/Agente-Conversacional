#include "../Comportamientos_Jugador/jugador.hpp"
#include "motorlib/util.h"

#include <iostream>
#include <cmath>
#include <set>
#include <stack>
#include <queue>

/*
	No se si tener en cuenta las casillas de Recarga en Costo Uniforme
	No olvidar los ---
	Tal vez se puede intentar hacer la funcion actualizarMapa mas eficiente
	Explicación de la función giro
*/

//  ______________________________________________________________________________ 
// |                                                                              |
// |                				Funciones		   	 		                  |
// |______________________________________________________________________________|

// Dado el código en carácter de una casilla del mapa dice si se puede
// pasar por ella sin riegos de morir o chocar
bool EsObstaculo(unsigned char casilla){
	if (casilla=='P' or casilla=='M')
		return true;
	else
	  	return false;
}

// Anula una matriz, esto es, la iguala a 0
void AnularMatriz(vector<vector<unsigned char> > &m){
	for (int i=0; i<m[0].size(); i++){
		for (int j=0; j<m.size(); j++){
			m[i][j]=0;
		}
	}
}

//  ______________________________________________________________________________ 
// |                                                                              |
// |                  	Métodos de ComportamientoJugador 		  	              |
// |______________________________________________________________________________|

// Este es el método principal que debe contener los 4 Comportamientos_Jugador
// que se piden en la práctica. Tiene como entrada la información de los
// sensores y devuelve la acción a realizar
Action ComportamientoJugador::think(Sensores sensores){
	actual.fila        = sensores.posF;
	actual.columna     = sensores.posC;
	actual.orientacion = sensores.sentido;

	destino.fila       = sensores.destinoF;
	destino.columna    = sensores.destinoC;

	Action accion = actIDLE;

	//Calculamos el camino hasta el destino si no tenemos aun un plan
	if(!hayPlan)
		hayPlan = pathFinding(sensores.nivel, actual, destino, plan);
	
	//---if(actual.fila == destino.fila and actual.columna == destino.columna)
	//	hayPlan = false;

	if(hayPlan and plan.size() > 0){			// Hay un plan no vacio
		if(sensores.nivel == 4){
			actualizarMapa(sensores);
			if( HayObstaculoDelante(actual) and plan.front() == actFORWARD){
				cerr << "\nRecalculando ruta ..." << endl;
				hayPlan = pathFinding(sensores.nivel, actual, destino, plan);	// Recalculamos el plan
			}
		}
		
		accion = plan.front();					// tomamos la siguiente accion del hayPlan
		plan.erase(plan.begin());				// eliminamos la accion de la lista de acciones
	}else{
		cerr << "\nRecalculando ruta ..." << endl;
		hayPlan = pathFinding(sensores.nivel, actual, destino, plan);	// Recalculamos el plan
	}

	return accion;
}

// Llama al algoritmo de busqueda que se usará en cada comportamiento del agente
// Level representa el comportamiento en el que fue iniciado el agente
bool ComportamientoJugador::pathFinding(int level, const estado &origen, const estado &destino, list<Action> &plan){
	switch (level){
		case 1: cout << "Busqueda en profundad\n";
			return pathFindingProfundidad(origen,destino,plan);
			break;
		case 2: cout << "Busqueda en Anchura\n";
			return pathFindingAnchura(origen,destino,plan);
			break;
		case 3: cout << "Busqueda Costo Uniforme\n";
			return pathFindingCostoUniforme(origen,destino,plan);
			break;
		case 4: cout << "Busqueda para el reto\n";
			return pathFindingBusquedaNivel2(origen,destino,plan);
			break;
	}
	cout << "Comportamiento sin implementar\n";
	return false;
}

// Comprueba si la casilla que hay delante es un obstaculo. Si es un
// obstaculo devuelve true. Si no es un obstaculo, devuelve false y
// modifica st con la posición de la casilla del avance
bool ComportamientoJugador::HayObstaculoDelante(estado &st){
	int fil=st.fila, col=st.columna;

  	// calculo cual es la casilla de delante del agente
	switch (st.orientacion) {
		case 0: fil--; break;
		case 1: col++; break;
		case 2: fil++; break;
		case 3: col--; break;
	}

	// Compruebo que no me salgo fuera del rango del mapa
	if (fil<0 or fil>=mapaResultado.size()) return true;
	if (col<0 or col>=mapaResultado[0].size()) return true;

	// Miro si en esa casilla hay un obstaculo infranqueable
	if (!EsObstaculo(mapaResultado[fil][col])){
		// No hay obstaculo, actualizo el parámetro st poniendo la casilla de delante.
    st.fila = fil;
		st.columna = col;
		return false;
	}
	else{
	  return true;
	}
}

// Sacar por la términal la secuencia del plan obtenido
void ComportamientoJugador::PintaPlan(list<Action> plan) {
	auto it = plan.begin();
	while (it!=plan.end()){
		if (*it == actFORWARD){
			cout << "A ";
		}
		else if (*it == actTURN_R){
			cout << "D ";
		}
		else if (*it == actTURN_L){
			cout << "I ";
		}
		else {
			cout << "- ";
		}
		it++;
	}
	cout << endl;
}

// Pinta sobre el mapa del juego el plan obtenido
void ComportamientoJugador::VisualizaPlan(const estado &st, const list<Action> &plan){
  	AnularMatriz(mapaConPlan);
	estado cst = st;

	auto it = plan.begin();
	while (it!=plan.end()){
		if (*it == actFORWARD){
			switch (cst.orientacion) {
				case 0: cst.fila--; break;
				case 1: cst.columna++; break;
				case 2: cst.fila++; break;
				case 3: cst.columna--; break;
			}
			mapaConPlan[cst.fila][cst.columna]=1;
		}
		else if (*it == actTURN_R){
			cst.orientacion = (cst.orientacion+1)%4;
		}
		else {
			cst.orientacion = (cst.orientacion+3)%4;
		}
		it++;
	}
}

int ComportamientoJugador::interact(Action accion, int valor){
	return false;
}

// Activa los atributos zapatillas y bikini si pasamos por una casilla de este tipo
void ComportamientoJugador::actualizarObjetos(const estado& st){
	int x = st.fila;
	int y = st.columna;

	if(mapaResultado[x][y] == 'D')
		zapatillas = true;
	if(mapaResultado[x][y] == 'K')
		bikini = true;
}

// Indica el coste que tiene cambiar del estado st a otro
int ComportamientoJugador::calcularCoste(const estado& st){
	int x = st.fila,
	    y = st.columna,
		res = 0;

	if(mapaResultado[x][y] == 'T')
		res = 2;
	else
		res = 1;
	
	if(mapaResultado[x][y] == 'A'){
		if(bikini)
			res = 10;
		else
			res = 100;
	}
	
	if(mapaResultado[x][y] == 'B'){
		if(zapatillas)
			res = 5;
		else
			res = 50;
	}
	
	return res;
}

// Actualiza el mapa
void ComportamientoJugador::actualizarMapa(Sensores sensores){
	estado est;
	int x       = actual.fila,
		y       = actual.columna,
		cont    = 0,
		n_giros = 0;

	if(sensores.sentido == este)  n_giros = 0;
	if(sensores.sentido == norte) n_giros = 1;
	if(sensores.sentido == oeste) n_giros = 2;
	if(sensores.sentido == sur)   n_giros = 3;

	cont = -1;
	for(int i = 1; i < 4; ++i){
		est = giro(x + cont, y + 1, n_giros);
		if(mapaResultado[est.fila][est.columna] == '?')
			mapaResultado[est.fila][est.columna] = sensores.terreno[i];
		cont++;
	}
	
	cont = -2; 
	for(int i = 4; i < 9; ++i){
		est = giro(x + cont, y + 2, n_giros);
		if(mapaResultado[est.fila][est.columna] == '?')
			mapaResultado[est.fila][est.columna] = sensores.terreno[i];
		cont++;
	}
	
	cont = -3; 
	for(int i = 9; i < 16; ++i){	
		est = giro(x + cont, y + 3, n_giros);
		if(mapaResultado[est.fila][est.columna] == '?')
			mapaResultado[est.fila][est.columna] = sensores.terreno[i];
		cont++;
	}
}

// Función giro a los puntos a, b de 90º en sentido levógiro n veces 
estado ComportamientoJugador::giro(int a, int b, int n){
	estado res;
	int xres = a - actual.fila,
		yres = b - actual.columna,
		aux  = 0;
	
	for(int i = 0; i < n; ++i){
		// Aplicamos el giro de 90º
		aux = xres;
		xres = -yres;
		yres = aux;
	}
 
	res.fila    = actual.fila    + xres;
	res.columna = actual.columna + yres;
	
	return res; 
}

/* --- Actualiza el mapa para ir mostrando lo que vamos descubriendo
void ComportamientoJugador::actualizarMapa(Sensores sensores){
	int x    = actual.fila,
		y    = actual.columna,
		cont = 0;

	if(mapaResultado[x][y] == '?') 
		mapaResultado[x][y] = sensores.terreno[0];
	
	switch (sensores.sentido){
		case este:
			cont = -1; 
			for(int i=1; i<4; ++i){	
				if(mapaResultado[x + cont][y + 1] == '?')
					mapaResultado[x + cont][y + 1] = sensores.terreno[i];
				cont++;
			}

			cont = -2; 
			for(int i=4; i<9; ++i){	
				if(mapaResultado[x + cont][y + 2] == '?')
					mapaResultado[x + cont][y + 2] = sensores.terreno[i];
				cont++;
			}

			cont = -3; 
			for(int i=9; i<16; ++i){	
				if(mapaResultado[x + cont][y + 3] == '?')
					mapaResultado[x + cont][y + 3] = sensores.terreno[i];
				cont++;
			}

			break;

		case sur:
			cont = -1; 
			for(int i=3; i>0; i--){	
				if(mapaResultado[x + 1][y + cont] == '?')
					mapaResultado[x + 1][y + cont] = sensores.terreno[i];
				cont++;
			}

			cont = -2; 
			for(int i=8; i>3; i--){	
				if(mapaResultado[x + 2][y + cont] == '?')
					mapaResultado[x + 2][y + cont] = sensores.terreno[i];
				cont++;
			}

			cont = -3; 
			for(int i=15; i>8; i--){	
				if(mapaResultado[x + 3][y + cont] == '?')
					mapaResultado[x + 3][y + cont] = sensores.terreno[i];
				cont++;
			}

			break;

		case oeste:
			cont = -1; 
			for(int i=3; i>0; i--){	
				if(mapaResultado[x + cont][y - 1] == '?')
					mapaResultado[x + cont][y - 1] = sensores.terreno[i];
				cont++;
			}

			cont = -2; 
			for(int i=8; i>3; i--){	
				if(mapaResultado[x + cont][y - 2] == '?')
					mapaResultado[x + cont][y - 2] = sensores.terreno[i];
				cont++;
			}

			cont = -3; 
			for(int i=15; i>8; i--){	
				if(mapaResultado[x + cont][y - 3] == '?')
					mapaResultado[x + cont][y - 3] = sensores.terreno[i];
				cont++;
			}

			break;

		case norte:
			cont = -1; 
			for(int i=1; i<4; ++i){	
				if(mapaResultado[x - 1][y + cont] == '?')
					mapaResultado[x - 1][y + cont] = sensores.terreno[i];
				cont++;
			}

			cont = -2; 
			for(int i=4; i<9; ++i){	
				if(mapaResultado[x - 2][y + cont] == '?')
					mapaResultado[x - 2][y + cont] = sensores.terreno[i];
				cont++;
			}

			cont = -3; 
			for(int i=9; i<16; ++i){	
				if(mapaResultado[x - 3][y + cont] == '?')
					mapaResultado[x - 3][y + cont] = sensores.terreno[i];
				cont++;
			}

			break;
	
		default:
			cerr << "\nSe ha producido algún fallo con los sensores" << endl;
			break;
	}
}*/

//  ______________________________________________________________________________ 
// |                                                                              |
// |                		  	   	Struct	     	  	  		                  |
// |______________________________________________________________________________|

struct ComparaEstados{
	bool operator()(const estado &a, const estado &n) const{
		if ((a.fila > n.fila) or (a.fila == n.fila and a.columna > n.columna) or
	      (a.fila == n.fila and a.columna == n.columna and a.orientacion > n.orientacion))
			return true;
		else
			return false;
	}
};

// Implementación del criterio de menor coste
struct CriterioDeOrden{
	bool operator ()(const nodo &a, const nodo &b) const{
		if (a.coste < b.coste)
			return true;
		else{
			if(a.coste == b.coste)
				ComparaEstados()(a.st,b.st);
			else
				return false;
		}
	}
};

//  ______________________________________________________________________________ 
// |                                                                              |
// |                		  Busqueda en Profundidad	     	                  |
// |______________________________________________________________________________|

// Implementación de la búsqueda en profundidad
// Entran los puntos origen y destino y devuelve la
// secuencia de acciones en plan, una lista de acciones
bool ComportamientoJugador::pathFindingProfundidad(const estado &origen, const estado &destino, list<Action> &plan){
	cout << "Calculando plan\n";
	plan.clear();
	set<estado,ComparaEstados> generados; // Lista de Cerrados		
	stack<nodo> pila;					  // Lista de Abiertos		

  	nodo current;
	current.st = origen;
	current.secuencia.empty();

	pila.push(current);

  	while (!pila.empty() and (current.st.fila!=destino.fila or current.st.columna != destino.columna)){
		pila.pop();
		generados.insert(current.st);

		// Generar descendiente de girar a la derecha
		nodo hijoTurnR = current;
		hijoTurnR.st.orientacion = (hijoTurnR.st.orientacion+1)%4;
		if (generados.find(hijoTurnR.st) == generados.end()){
			hijoTurnR.secuencia.push_back(actTURN_R);
			pila.push(hijoTurnR);
		}

		// Generar descendiente de girar a la izquierda
		nodo hijoTurnL = current;
		hijoTurnL.st.orientacion = (hijoTurnL.st.orientacion+3)%4;
		if (generados.find(hijoTurnL.st) == generados.end()){
			hijoTurnL.secuencia.push_back(actTURN_L);
			pila.push(hijoTurnL);
		}

		// Generar descendiente de avanzar
		nodo hijoForward = current;
		if (!HayObstaculoDelante(hijoForward.st)){
			if (generados.find(hijoForward.st) == generados.end()){
				hijoForward.secuencia.push_back(actFORWARD);
				pila.push(hijoForward);
			}
		}

		// Tomo el siguiente valor de la pila
		if (!pila.empty()){
			current = pila.top();
		}
	}

  	cout << "Terminada la busqueda\n";

	if (current.st.fila == destino.fila and current.st.columna == destino.columna){
		cout << "Cargando el plan\n";
		plan = current.secuencia;
		cout << "Longitud del plan: " << plan.size() << endl;
		PintaPlan(plan);
		// ver el plan en el mapa
		VisualizaPlan(origen, plan);
		return true;
	}
	else {
		cout << "\nNo encontrado plan\n";
	}

	return false;
}

//  ______________________________________________________________________________ 
// |                                                                              |
// |                			Busqueda en Anchura	   	 		                  |
// |______________________________________________________________________________|

// Implementación de la búsqueda en anchura
bool ComportamientoJugador::pathFindingAnchura(const estado &origen, const estado &destino, list<Action> &plan){
	cout << "\nCalculando plan...\n";
	plan.clear();
	
	set<estado,ComparaEstados> generados;		// Lista de Cerrados		
	queue <nodo> cola;							// Lista de Abiertos		
 	
	nodo current;
	current.st = origen;
	current.secuencia.empty();

	cola.push(current);

	while (!cola.empty() and (current.st.fila != destino.fila or current.st.columna != destino.columna)){
		cola.pop();
		generados.insert(current.st);
		
		// Generar descendiente de girar a la derecha
		nodo hijoTurnR = current;
		hijoTurnR.st.orientacion = (hijoTurnR.st.orientacion+1)%4;
		if (generados.find(hijoTurnR.st) == generados.end()){
			hijoTurnR.secuencia.push_back(actTURN_R);
			cola.push(hijoTurnR);
		}

		// Generar descendiente de girar a la izquierda
		nodo hijoTurnL = current;
		hijoTurnL.st.orientacion = (hijoTurnL.st.orientacion+3)%4;
		if (generados.find(hijoTurnL.st) == generados.end()){
			hijoTurnL.secuencia.push_back(actTURN_L);
			cola.push(hijoTurnL);
		}

		// Generar descendiente de avanzar
		nodo hijoForward = current;
		if (!HayObstaculoDelante(hijoForward.st)){
			if (generados.find(hijoForward.st) == generados.end()){
				hijoForward.secuencia.push_back(actFORWARD);
				cola.push(hijoForward);
			}
		}

		// Tomo el siguiente valor de la cola
		if (!cola.empty()){
			current = cola.front();
		}
	}
	
	cout << "Busqueda terminada!\n";

	if (current.st.fila == destino.fila and current.st.columna == destino.columna){
		cout << "Cargando el plan...\n";
		plan = current.secuencia;
		cout << "Longitud del plan: " << plan.size() << endl;
		PintaPlan(plan);
		VisualizaPlan(origen, plan);	// Ver el plan en el mapa
		return true;
	}else
		cout << "\nNo se ha encontrado plan :(\n";

	return false;
}

//  ______________________________________________________________________________ 
// |                                                                              |
// |                		 Busqueda de Costo Uniforme   		                  |
// |______________________________________________________________________________|

// Implementación de la búsqueda de costo uniforme
bool ComportamientoJugador::pathFindingCostoUniforme(const estado &origen, const estado &destino, list<Action> &plan){
	cout << "\nCalculando plan...\n";
	plan.clear();
	
	set<estado, ComparaEstados> cerrados;			// Lista de Cerrados
	set<nodo, CriterioDeOrden> 	abiertos;			// Lista de Abiertos

	nodo current;
	current.st = origen;
	current.secuencia.empty();
	current.coste = 0;

	abiertos.insert(current);

	while (!abiertos.empty() and (current.st.fila != destino.fila or current.st.columna != destino.columna)){
		cerrados.insert(current.st);
		abiertos.erase(current);
		
		actualizarObjetos(current.st);

		// Generar descendiente de girar a la derecha
		nodo hijoTurnR = current;
		hijoTurnR.st.orientacion = (hijoTurnR.st.orientacion+1)%4;				// Modifico la orientación
		hijoTurnR.coste += calcularCoste(current.st);	  						// Incremento el coste del nodo por haber cambiado de estado
		if (cerrados.find(hijoTurnR.st) == cerrados.end()){						// Si no he pasado por hijoTurnR aún
			hijoTurnR.secuencia.push_back(actTURN_R);		
			abiertos.insert(hijoTurnR);
		}

		// Generar descendiente de girar a la izquierda
		nodo hijoTurnL = current;
		hijoTurnL.st.orientacion = (hijoTurnL.st.orientacion+3)%4;
		hijoTurnL.coste += calcularCoste(current.st);
		if (cerrados.find(hijoTurnL.st) == cerrados.end()){
			hijoTurnL.secuencia.push_back(actTURN_L);
			abiertos.insert(hijoTurnL);
		}

		// Generar descendiente de avanzar
		nodo hijoForward = current;
		hijoForward.coste += calcularCoste(current.st);
		if (!HayObstaculoDelante(hijoForward.st)){
			if (cerrados.find(hijoForward.st) == cerrados.end()){
				hijoForward.secuencia.push_back(actFORWARD);
				abiertos.insert(hijoForward);
			}
		}

		// Tomo el siguiente valor de la cola
		if (!abiertos.empty()){
			current = *(abiertos.begin());										// current toma el valor del primer elemento del set
		}
	}

	cout << "Busqueda terminada!\n";

	if (current.st.fila == destino.fila and current.st.columna == destino.columna){
		cout << "Cargando el plan...\n";
		plan = current.secuencia;
		cout << "Longitud del plan: " << plan.size() << endl;
		PintaPlan(plan);
		VisualizaPlan(origen, plan);		// ver el plan en el mapa
		return true;
	}
	else
		cout << "\nNo se ha encontrado plan :(\n";

	return false;	
}

//  ______________________________________________________________________________ 
// |                                                                              |
// |                 		 Busqueda del Nivel 2		      		              |
// |______________________________________________________________________________|

bool ComportamientoJugador::pathFindingBusquedaNivel2(const estado& origen, const estado& destino, list<Action> &plan){
	pathFindingCostoUniforme(origen,destino,plan);		//---
	return true;
}
